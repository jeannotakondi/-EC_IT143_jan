-- Q: How to extract first name from Contact Name?

-- A: ContactName = Maria Anders -> Maria
-- Youtube video "How to extract first name from combined name tsql"
-- https://youtu.be/Qc7Gi__bJkI?si=LhYkMWO7HjJDlqeU

USE EC_IT143_DA

SELECT t.ContactName
	, LEFT(t.ContactName, CHARINDEX(' ', t.ContactName + ' ') - 1) AS first_name
FROM dbo.t_w3_schools_customers AS t
ORDER BY 1;