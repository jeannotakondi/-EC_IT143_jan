USE EC_IT143_DA

SELECT t.ContactName
	, LEFT(t.ContactName, CHARINDEX(' ', t.ContactName + ' ') - 1) AS first_name1
	, dbo.ufn_GetFirstName(ContactName) AS first_Name2
FROM dbo.t_w3_schools_customers AS t
ORDER BY 1;