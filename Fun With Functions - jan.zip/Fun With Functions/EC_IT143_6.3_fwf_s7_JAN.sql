--  A script that will return 0 results (zero records) IF our function is working as expected. 

USE EC_IT143_DA

SELECT ContactName,
       dbo.ufn_GetFirstName(ContactName) AS ExtractedFirstName
FROM dbo.t_w3_schools_customers
WHERE dbo.ufn_GetFirstName(ContactName) <> 
      LEFT(LTRIM(ContactName), CHARINDEX(' ', LTRIM(ContactName) + ' ') - 1);
