-- Q: How to extract first name from Contact Name?

-- A: We have ContactName Maria Anders -> Maria