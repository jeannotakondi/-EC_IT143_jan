/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwf_s5_JAN.sql
PURPOSE: Create a user-defined scalar function

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     08/12/2025   J.Akondi     1. Built this script for EC IT143


RUNTIME: 
Xm Xs

NOTES: 
Adapted from an example video and some understanding from: https://youtu.be/Qc7Gi__bJkI?si=LhYkMWO7HjJDlqeU
 
******************************************************************************************************************/
IF OBJECT_ID('dbo.ufn_GetFirstName', 'FN') IS NOT NULL
    DROP FUNCTION dbo.ufn_GetFirstName;
GO

CREATE FUNCTION dbo.ufn_GetFirstName
(
    @FullName NVARCHAR(255)
)
RETURNS NVARCHAR(255)
AS
BEGIN
    DECLARE @FirstName NVARCHAR(255);

    -- Find position of first space
    DECLARE @SpacePos INT = CHARINDEX(' ', LTRIM(@FullName));
    
    IF @SpacePos > 0
        SET @FirstName = LEFT(LTRIM(@FullName), @SpacePos - 1);
    ELSE
        -- No space found, return full name
        SET @FirstName = LTRIM(@FullName);

    RETURN @FirstName;
END;
GO

USE EC_IT143_DA

SELECT ContactName,
       dbo.ufn_GetFirstName(ContactName) AS FirstName
FROM dbo.t_w3_schools_customers;
