-- 6.4 Performance Analysis --
-- By Jeannot Akondi --


-- Step 1:  Query a table in your AdventureWorks SQL Server Database.

SELECT 
    SalesOrderID,
    ProductID,
    OrderQty,
    UnitPrice,
    LineTotal
FROM Sales.SalesOrderDetail
