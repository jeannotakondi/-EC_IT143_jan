-- 6.4 Performance Analysis --
-- By Jeannot Akondi --


-- Step 3:  Include the Actual Execution Plan.




SELECT 
    SalesOrderID,
    ProductID,
    OrderQty,
    UnitPrice,
    LineTotal
FROM Sales.SalesOrderDetail
WHERE SpecialOfferID = 2
  AND CarrierTrackingNumber = '4911-403C-98';


-- Step 4: Review the execution plan.
-- Step 5:  The estimated subtree cost and any missing index recommendations.
--          Estimated subtree cost = 1.07359
--          Missing index recommendations: Missing Index (Impact 99.6725): CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,>] ON [Sales].[SalesOrderDetail] ([CarrierTrackingNumber],[SpecialOfferID]) 