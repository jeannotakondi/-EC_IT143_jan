-- 6.4 Performance Analysis --
-- By Jeannot Akondi --


-- Step 8:  Re-run the query to see if performance improves in terms of runtime and estimated subtree cost.
--            Estimated Subtree Cost = 0.515525



SELECT 
    SalesOrderID,
    ProductID,
    OrderQty,
    UnitPrice,
    LineTotal
FROM Sales.SalesOrderDetail
WHERE SpecialOfferID = 2
  AND CarrierTrackingNumber = '4911-403C-98';