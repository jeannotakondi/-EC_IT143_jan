/*
Missing Index Details from SQLQuery3.sql - (local).Adv
The Query Processor estimates that implementing the following missing index will have an impact of 99.6725
 Step 7: Name the index and execute the script.
*/



USE AdventureWorks2022
GO
CREATE NONCLUSTERED INDEX IX_sales_triage_optimizer 
ON [Sales].[SalesOrderDetail] ([CarrierTrackingNumber],[SpecialOfferID]) 

