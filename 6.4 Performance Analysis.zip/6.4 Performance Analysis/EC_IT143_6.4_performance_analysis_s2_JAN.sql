-- 6.4 Performance Analysis --
-- By Jeannot Akondi --


-- Step 2:  Add a WHERE clause that limits to a specific value for a character field (one that is not indexed).


SELECT 
    SalesOrderID,
    ProductID,
    OrderQty,
    UnitPrice,
    LineTotal
FROM Sales.SalesOrderDetail
WHERE SpecialOfferID = 2
  AND CarrierTrackingNumber = '4911-403C-98';