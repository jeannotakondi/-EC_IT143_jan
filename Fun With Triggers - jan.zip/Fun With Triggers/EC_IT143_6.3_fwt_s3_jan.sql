-- Q1:  How to keep track of when a record was last modified.
-- A1: To track when a record was last modified, 
--    add a datetime column (for example, LastModifiedDate) to the table and update it automatically whenever the record changes. 

--ALTER TABLE dbo.t_hello_world_count_JAN
--ADD LastModifiedDate DATETIME DEFAULT GETDATE();

--  Q2:  How to keep track of who last modified a record.
--  A2:  This can be done using a trigger or by including the column update in your INSERT and UPDATE statements.

-- https://learn.microsoft.com/en-us/sql/relational-databases/track-changes/track-data-changes-sql-server?view=sql-server-ver17
-- https://stackoverflow.com/questions/29834515/how-to-find-who-last-modified-the-table-in-sql-server