/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwf_s5_JAN.sql
PURPOSE: Create an after-update trigger

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     08/12/2025   J.Akondi     1. Built this script for EC IT143


RUNTIME: 
Xm Xs

NOTES: 
Adapted from a course example video and some understanding from: 
-- https://learn.microsoft.com/en-us/sql/relational-databases/track-changes/track-data-changes-sql-server?view=sql-server-ver17
-- https://stackoverflow.com/questions/29834515/how-to-find-who-last-modified-the-table-in-sql-server
 
******************************************************************************************************************/

-- Drop the trigger if it already exists to avoid an error
IF OBJECT_ID('dbo.trg_UpdateSnapshotUTC', 'TR') IS NOT NULL
    DROP TRIGGER dbo.trg_UpdateSnapshotUTC;
GO

-- Create the trigger
CREATE TRIGGER dbo.trg_UpdateSnapshotUTC
ON dbo.t_hello_world_count_JAN  
AFTER UPDATE
AS
BEGIN
    -- We are updating LastModifiedDate whenever a record is updated
    SET NOCOUNT ON;

    UPDATE T
    SET LastModifiedDate = GETUTCDATE()   -- Set to current UTC date/time
    FROM dbo.t_hello_world_count_JAN AS T
    INNER JOIN inserted AS i ON T.Snapshot_id = i.Snapshot_id; 
    -- 'inserted' is a virtual table containing the new version of updated rows
END;
GO
