
-- Show before
SELECT * FROM dbo.t_hello_world_count_JAN;

-- Update the dummy column to trigger the AFTER UPDATE
UPDATE dbo.t_hello_world_count_JAN
SET Notes = 'Test update'
WHERE Snapshot_id = 1;   -- Use an actual ID from your table

-- Show after
SELECT * FROM dbo.t_hello_world_count_JAN;