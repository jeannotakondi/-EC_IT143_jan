-- Q1:  How to keep track of when a record was last modified.
-- A1: To track when a record was last modified, 
--    add a datetime column (for example, LastModifiedDate) to the table and update it automatically whenever the record changes. 

ALTER TABLE dbo.t_hello_world_count_JAN
ADD LastModifiedDate DATETIME DEFAULT GETDATE();

